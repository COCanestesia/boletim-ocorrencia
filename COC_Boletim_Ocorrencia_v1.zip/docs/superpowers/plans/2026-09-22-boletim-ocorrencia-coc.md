# Boletim de Ocorrência COC Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Construir um aplicativo Streamlit público e separado, executado localmente no Windows, que cria boletins de ocorrência, salva tudo em SQLite e pastas locais, gera PDF/ZIP e importa boletins recebidos em modo somente leitura.

**Architecture:** O aplicativo será dividido em domínio/repositório local, serviços de anexos e intercâmbio, e interface Streamlit. O SQLite guarda metadados e estado; arquivos ficam sob `%LOCALAPPDATA%\COC\BoletimOcorrencia`. A identidade é obtida automaticamente do usuário do Windows; nenhum login do aplicativo é exigido.

**Tech Stack:** Python 3.12+, Streamlit 1.50+, SQLite 3 (stdlib `sqlite3`), ReportLab 4.4+, stdlib `zipfile`, `hashlib`, `json`, `pathlib`, Pytest 8.4+.

**Spec:** `docs/superpowers/specs/2026-09-22-boletim-ocorrencia-coc-design.md`

## Global Constraints

- O aplicativo roda localmente em Windows e não depende de Supabase.
- Não existe tela de login nem senha do aplicativo.
- A identidade do autor vem automaticamente do usuário do Windows.
- Os dados ficam em `%LOCALAPPDATA%\COC\BoletimOcorrencia`.
- O SQLite é a fonte oficial local dos registros.
- **Meus Registros** mostra apenas registros `origem = local` do usuário atual do Windows.
- Boletins `finalizado` são imutáveis.
- Boletins `recebido` são imutáveis.
- O aplicativo deve gerar PDF individual e ZIP completo com `boletim.pdf`, `boletim.json` e `anexos/`.
- Importações devem validar estrutura, integridade, UUID/hash e impedir duplicação.
- Extensões aceitas inicialmente: PDF, JPG, JPEG, PNG, DOCX e XLSX.
- Arquivos recebidos nunca são executados.
- O repositório público não pode versionar bancos, anexos, exportações, logs nem dados reais.

## Review Focus

1. **ZIP malicioso com `../` ou caminhos absolutos:** a importação deve rejeitar o pacote antes de extrair qualquer arquivo.
2. **Mesmo boletim importado duas vezes ou ZIP renomeado:** deve ser detectado por UUID/hash e não criar duplicata.
3. **Anexo com extensão permitida mas nome perigoso (`..\x.pdf`, nomes reservados ou caracteres inválidos):** deve ser renomeado para um nome local seguro sem perder o nome original no banco.
4. **Boletim finalizado/recebido submetido a atualização por chamada interna:** o repositório deve rejeitar a escrita, independentemente da interface.
5. **Falha parcial ao importar/exportar (arquivo ausente, hash inválido, disco sem escrita):** nenhuma entrada incompleta deve ser marcada como importada/finalizada.

---

## File Structure

```text
boletim-ocorrencia-coc/
├── app.py
├── requirements.txt
├── .gitignore
├── README.md
├── run_coc.bat
├── boletim_coc/
│   ├── __init__.py
│   ├── config.py
│   ├── identity.py
│   ├── models.py
│   ├── db.py
│   ├── repository.py
│   ├── attachments.py
│   ├── pdf_export.py
│   ├── package_export.py
│   ├── package_import.py
│   ├── theme.py
│   └── views/
│       ├── __init__.py
│       ├── new_record.py
│       ├── my_records.py
│       ├── received.py
│       └── detail.py
├── tests/
│   ├── test_config_identity.py
│   ├── test_repository.py
│   ├── test_attachments.py
│   ├── test_pdf_export.py
│   ├── test_package_export.py
│   └── test_package_import.py
└── docs/
    └── superpowers/
        ├── specs/
        │   └── 2026-09-22-boletim-ocorrencia-coc-design.md
        └── plans/
            └── 2026-09-22-boletim-ocorrencia-coc.md
```

Responsibilities:

- `config.py`: resolve diretórios locais e limites de arquivo.
- `identity.py`: identificar o usuário do Windows.
- `models.py`: tipos de domínio e validações simples.
- `db.py`: abrir SQLite, aplicar schema e transações.
- `repository.py`: CRUD, filtros, imutabilidade e deduplicação.
- `attachments.py`: sanitizar, salvar, ler e hashear anexos.
- `pdf_export.py`: gerar o documento PDF.
- `package_export.py`: montar `boletim.json` e ZIP.
- `package_import.py`: validar/importar ZIP externo com proteção contra path traversal.
- `theme.py`: CSS e elementos visuais compartilhados.
- `views/*`: telas Streamlit, sem SQL direto.

---

### Task 1: Bootstrap local, paths e banco SQLite

**Files:**
- Create: `requirements.txt`
- Create: `.gitignore`
- Create: `boletim_coc/__init__.py`
- Create: `boletim_coc/config.py`
- Create: `boletim_coc/identity.py`
- Create: `boletim_coc/db.py`
- Test: `tests/test_config_identity.py`
- Test: `tests/test_repository.py` (schema smoke test)

**Interfaces:**
- Produces: `AppPaths`, `resolve_paths() -> AppPaths`, `current_windows_user() -> str`, `connect_db(paths: AppPaths) -> sqlite3.Connection`, `initialize_database(conn) -> None`.
- Consumes: only Python stdlib.

- [ ] **Step 1: Create dependency and ignore files**

`requirements.txt`:

```text
streamlit>=1.50,<2
reportlab>=4.4,<5
pytest>=8.4,<9
```

`.gitignore`:

```gitignore
__pycache__/
*.py[cod]
.pytest_cache/
.venv/
venv/
*.db
*.sqlite
*.sqlite3
data/
anexos/
recebidos/
exportados/
logs/
.env
.streamlit/secrets.toml
```

- [ ] **Step 2: Write failing tests for paths and Windows identity**

`tests/test_config_identity.py`:

```python
from pathlib import Path

from boletim_coc.config import resolve_paths
from boletim_coc.identity import current_windows_user


def test_resolve_paths_uses_localappdata(monkeypatch, tmp_path):
    monkeypatch.setenv("LOCALAPPDATA", str(tmp_path))
    paths = resolve_paths()
    assert paths.root == tmp_path / "COC" / "BoletimOcorrencia"
    assert paths.database == paths.root / "boletins.db"
    assert paths.attachments == paths.root / "anexos"
    assert paths.received == paths.root / "recebidos"
    assert paths.exports == paths.root / "exportados"
    assert paths.logs == paths.root / "logs"


def test_resolve_paths_creates_directories(monkeypatch, tmp_path):
    monkeypatch.setenv("LOCALAPPDATA", str(tmp_path))
    paths = resolve_paths()
    for folder in [paths.root, paths.attachments, paths.received, paths.exports, paths.logs]:
        assert folder.is_dir()


def test_current_windows_user_returns_nonempty(monkeypatch):
    monkeypatch.setattr("getpass.getuser", lambda: "MARIA.COC")
    assert current_windows_user() == "MARIA.COC"
```

- [ ] **Step 3: Run config tests and verify failure**

Run:

```bash
pytest tests/test_config_identity.py -v
```

Expected: FAIL because `boletim_coc.config` and `boletim_coc.identity` do not exist.

- [ ] **Step 4: Implement paths and identity**

`boletim_coc/config.py`:

```python
from dataclasses import dataclass
import os
from pathlib import Path

MAX_ATTACHMENT_BYTES = 25 * 1024 * 1024
ALLOWED_EXTENSIONS = {".pdf", ".jpg", ".jpeg", ".png", ".docx", ".xlsx"}


@dataclass(frozen=True)
class AppPaths:
    root: Path
    database: Path
    attachments: Path
    received: Path
    exports: Path
    logs: Path


def resolve_paths() -> AppPaths:
    base = Path(os.environ.get("LOCALAPPDATA") or Path.home() / "AppData" / "Local")
    root = base / "COC" / "BoletimOcorrencia"
    paths = AppPaths(
        root=root,
        database=root / "boletins.db",
        attachments=root / "anexos",
        received=root / "recebidos",
        exports=root / "exportados",
        logs=root / "logs",
    )
    for folder in [paths.root, paths.attachments, paths.received, paths.exports, paths.logs]:
        folder.mkdir(parents=True, exist_ok=True)
    return paths
```

`boletim_coc/identity.py`:

```python
import getpass


def current_windows_user() -> str:
    value = str(getpass.getuser() or "").strip()
    if not value:
        raise RuntimeError("Não foi possível identificar o usuário do Windows.")
    return value
```

- [ ] **Step 5: Write failing schema smoke test**

Append to `tests/test_repository.py`:

```python
from boletim_coc.config import AppPaths
from boletim_coc.db import connect_db, initialize_database


def make_paths(tmp_path):
    return AppPaths(
        root=tmp_path,
        database=tmp_path / "boletins.db",
        attachments=tmp_path / "anexos",
        received=tmp_path / "recebidos",
        exports=tmp_path / "exportados",
        logs=tmp_path / "logs",
    )


def test_initialize_database_creates_tables(tmp_path):
    paths = make_paths(tmp_path)
    conn = connect_db(paths)
    initialize_database(conn)
    names = {
        row[0]
        for row in conn.execute("select name from sqlite_master where type='table'")
    }
    assert {"boletins", "anexos", "importacoes"} <= names
```

- [ ] **Step 6: Run schema test and verify failure**

```bash
pytest tests/test_repository.py::test_initialize_database_creates_tables -v
```

Expected: FAIL because `boletim_coc.db` does not exist.

- [ ] **Step 7: Implement SQLite schema**

`boletim_coc/db.py`:

```python
import sqlite3

from boletim_coc.config import AppPaths

SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS boletins (
    id TEXT PRIMARY KEY,
    codigo TEXT NOT NULL UNIQUE,
    origem TEXT NOT NULL CHECK(origem IN ('local','recebido')),
    windows_user TEXT NOT NULL,
    autor_original TEXT NOT NULL,
    data_ocorrencia TEXT NOT NULL,
    hora_ocorrencia TEXT NOT NULL,
    local TEXT NOT NULL,
    setor TEXT NOT NULL,
    tipo_ocorrencia TEXT NOT NULL,
    titulo TEXT NOT NULL,
    descricao TEXT NOT NULL,
    consequencias TEXT NOT NULL DEFAULT '',
    pessoas_envolvidas TEXT NOT NULL DEFAULT '',
    acoes_imediatas TEXT NOT NULL DEFAULT '',
    acoes_preventivas TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL CHECK(status IN ('rascunho','finalizado')),
    criado_em TEXT NOT NULL,
    atualizado_em TEXT NOT NULL,
    finalizado_em TEXT,
    hash_conteudo TEXT
);

CREATE INDEX IF NOT EXISTS idx_boletins_owner
ON boletins(origem, windows_user, criado_em DESC);

CREATE TABLE IF NOT EXISTS anexos (
    id TEXT PRIMARY KEY,
    boletim_id TEXT NOT NULL REFERENCES boletins(id) ON DELETE CASCADE,
    nome_original TEXT NOT NULL,
    nome_armazenado TEXT NOT NULL,
    caminho_relativo TEXT NOT NULL,
    mime_type TEXT NOT NULL,
    tamanho_bytes INTEGER NOT NULL,
    sha256 TEXT NOT NULL,
    criado_em TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS importacoes (
    id TEXT PRIMARY KEY,
    boletim_id TEXT NOT NULL UNIQUE REFERENCES boletins(id) ON DELETE CASCADE,
    arquivo_origem TEXT NOT NULL,
    importado_em TEXT NOT NULL,
    hash_pacote TEXT NOT NULL UNIQUE
);
"""


def connect_db(paths: AppPaths) -> sqlite3.Connection:
    paths.root.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(paths.database, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def initialize_database(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA)
    conn.commit()
```

- [ ] **Step 8: Run Task 1 tests**

```bash
pytest tests/test_config_identity.py tests/test_repository.py::test_initialize_database_creates_tables -v
```

Expected: PASS.

- [ ] **Step 9: Commit**

```bash
git add requirements.txt .gitignore boletim_coc tests
git commit -m "feat: add local storage foundation"
```

---

### Task 2: Domain model, owner filtering and immutable states

**Files:**
- Create: `boletim_coc/models.py`
- Create: `boletim_coc/repository.py`
- Modify: `tests/test_repository.py`

**Interfaces:**
- Consumes: `sqlite3.Connection`.
- Produces:
  - `BoletimDraft`
  - `create_boletim(conn, draft, windows_user) -> sqlite3.Row`
  - `get_boletim(conn, boletim_id) -> sqlite3.Row | None`
  - `list_my_records(conn, windows_user, query="", status=None, tipo=None) -> list[sqlite3.Row]`
  - `update_draft(conn, boletim_id, changes) -> sqlite3.Row`
  - `finalize_boletim(conn, boletim_id) -> sqlite3.Row`
  - `next_codigo(conn, year) -> str`

- [ ] **Step 1: Write failing repository behavior tests**

Append to `tests/test_repository.py`:

```python
from datetime import date, time
import pytest

from boletim_coc.models import BoletimDraft
from boletim_coc.repository import (
    create_boletim,
    finalize_boletim,
    list_my_records,
    update_draft,
)


def open_db(tmp_path):
    paths = make_paths(tmp_path)
    conn = connect_db(paths)
    initialize_database(conn)
    return conn


def sample_draft(titulo="Queda no corredor"):
    return BoletimDraft(
        data_ocorrencia=date(2026, 9, 22),
        hora_ocorrencia=time(8, 30),
        local="Hospital COC",
        setor="Centro cirúrgico",
        tipo_ocorrencia="Segurança",
        titulo=titulo,
        descricao="Descrição completa da ocorrência.",
        consequencias="Sem dano.",
        pessoas_envolvidas="Equipe do setor.",
        acoes_imediatas="Área sinalizada.",
        acoes_preventivas="Revisar rotina.",
    )


def test_list_my_records_isolates_windows_user(tmp_path):
    conn = open_db(tmp_path)
    create_boletim(conn, sample_draft("A"), "MARIA")
    create_boletim(conn, sample_draft("B"), "JOAO")
    rows = list_my_records(conn, "MARIA")
    assert [row["titulo"] for row in rows] == ["A"]


def test_finalized_record_cannot_be_edited(tmp_path):
    conn = open_db(tmp_path)
    row = create_boletim(conn, sample_draft(), "MARIA")
    finalize_boletim(conn, row["id"])
    with pytest.raises(PermissionError, match="finalizado"):
        update_draft(conn, row["id"], {"titulo": "Alterado"})


def test_received_record_cannot_be_edited(tmp_path):
    conn = open_db(tmp_path)
    row = create_boletim(conn, sample_draft(), "MARIA")
    conn.execute("update boletins set origem='recebido' where id=?", (row["id"],))
    conn.commit()
    with pytest.raises(PermissionError, match="recebido"):
        update_draft(conn, row["id"], {"titulo": "Alterado"})


def test_codes_increment_per_year(tmp_path):
    conn = open_db(tmp_path)
    first = create_boletim(conn, sample_draft("A"), "MARIA")
    second = create_boletim(conn, sample_draft("B"), "MARIA")
    assert first["codigo"] == "COC-2026-000001"
    assert second["codigo"] == "COC-2026-000002"
```

- [ ] **Step 2: Run repository tests and verify failure**

```bash
pytest tests/test_repository.py -v
```

Expected: FAIL on missing `models`/`repository`.

- [ ] **Step 3: Implement domain model**

`boletim_coc/models.py`:

```python
from dataclasses import dataclass
from datetime import date, time


@dataclass(frozen=True)
class BoletimDraft:
    data_ocorrencia: date
    hora_ocorrencia: time
    local: str
    setor: str
    tipo_ocorrencia: str
    titulo: str
    descricao: str
    consequencias: str = ""
    pessoas_envolvidas: str = ""
    acoes_imediatas: str = ""
    acoes_preventivas: str = ""

    def validate(self) -> None:
        required = {
            "local": self.local,
            "setor": self.setor,
            "tipo_ocorrencia": self.tipo_ocorrencia,
            "titulo": self.titulo,
            "descricao": self.descricao,
        }
        missing = [name for name, value in required.items() if not str(value).strip()]
        if missing:
            raise ValueError("Campos obrigatórios: " + ", ".join(missing))
```

- [ ] **Step 4: Implement repository operations**

`boletim_coc/repository.py`:

```python
from datetime import datetime, timezone
import sqlite3
import uuid

from boletim_coc.models import BoletimDraft


def now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def next_codigo(conn: sqlite3.Connection, year: int) -> str:
    prefix = f"COC-{year}-"
    row = conn.execute(
        "select codigo from boletins where codigo like ? order by codigo desc limit 1",
        (prefix + "%",),
    ).fetchone()
    seq = int(row["codigo"].split("-")[-1]) + 1 if row else 1
    return f"{prefix}{seq:06d}"


def get_boletim(conn: sqlite3.Connection, boletim_id: str):
    return conn.execute("select * from boletins where id=?", (boletim_id,)).fetchone()


def create_boletim(conn: sqlite3.Connection, draft: BoletimDraft, windows_user: str):
    draft.validate()
    record_id = str(uuid.uuid4())
    stamp = now_iso()
    codigo = next_codigo(conn, draft.data_ocorrencia.year)
    conn.execute(
        """
        insert into boletins(
            id,codigo,origem,windows_user,autor_original,
            data_ocorrencia,hora_ocorrencia,local,setor,tipo_ocorrencia,
            titulo,descricao,consequencias,pessoas_envolvidas,
            acoes_imediatas,acoes_preventivas,status,criado_em,atualizado_em
        ) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """,
        (
            record_id, codigo, "local", windows_user, windows_user,
            draft.data_ocorrencia.isoformat(),
            draft.hora_ocorrencia.strftime("%H:%M"),
            draft.local.strip(), draft.setor.strip(), draft.tipo_ocorrencia.strip(),
            draft.titulo.strip(), draft.descricao.strip(), draft.consequencias.strip(),
            draft.pessoas_envolvidas.strip(), draft.acoes_imediatas.strip(),
            draft.acoes_preventivas.strip(), "rascunho", stamp, stamp,
        ),
    )
    conn.commit()
    return get_boletim(conn, record_id)


def list_my_records(conn, windows_user: str, query="", status=None, tipo=None):
    sql = "select * from boletins where origem='local' and windows_user=?"
    args = [windows_user]
    if query:
        sql += " and (titulo like ? or descricao like ? or codigo like ? or local like ?)"
        like = f"%{query.strip()}%"
        args += [like, like, like, like]
    if status:
        sql += " and status=?"
        args.append(status)
    if tipo:
        sql += " and tipo_ocorrencia=?"
        args.append(tipo)
    sql += " order by criado_em desc"
    return list(conn.execute(sql, args).fetchall())


def _assert_editable(row) -> None:
    if row is None:
        raise KeyError("Boletim não encontrado.")
    if row["origem"] == "recebido":
        raise PermissionError("Boletim recebido é somente leitura.")
    if row["status"] == "finalizado":
        raise PermissionError("Boletim finalizado não pode ser editado.")


def update_draft(conn, boletim_id: str, changes: dict):
    row = get_boletim(conn, boletim_id)
    _assert_editable(row)
    allowed = {
        "data_ocorrencia","hora_ocorrencia","local","setor","tipo_ocorrencia",
        "titulo","descricao","consequencias","pessoas_envolvidas",
        "acoes_imediatas","acoes_preventivas",
    }
    clean = {k: v for k, v in changes.items() if k in allowed}
    if not clean:
        return row
    setters = ", ".join(f"{k}=?" for k in clean)
    values = list(clean.values()) + [now_iso(), boletim_id]
    conn.execute(
        f"update boletins set {setters}, atualizado_em=? where id=?",
        values,
    )
    conn.commit()
    return get_boletim(conn, boletim_id)


def finalize_boletim(conn, boletim_id: str):
    row = get_boletim(conn, boletim_id)
    _assert_editable(row)
    stamp = now_iso()
    conn.execute(
        "update boletins set status='finalizado', finalizado_em=?, atualizado_em=? where id=?",
        (stamp, stamp, boletim_id),
    )
    conn.commit()
    return get_boletim(conn, boletim_id)
```

- [ ] **Step 5: Add search filter test**

Append:

```python
def test_list_my_records_searches_title_and_code(tmp_path):
    conn = open_db(tmp_path)
    create_boletim(conn, sample_draft("Falha no equipamento"), "MARIA")
    create_boletim(conn, sample_draft("Outro registro"), "MARIA")
    assert len(list_my_records(conn, "MARIA", query="equipamento")) == 1
    assert len(list_my_records(conn, "MARIA", query="COC-2026-000001")) == 1
```

- [ ] **Step 6: Run Task 2 tests**

```bash
pytest tests/test_repository.py -v
```

Expected: PASS.

- [ ] **Step 7: Commit**

```bash
git add boletim_coc/models.py boletim_coc/repository.py tests/test_repository.py
git commit -m "feat: add local bulletin repository"
```

---

### Task 3: Secure local attachment storage

**Files:**
- Create: `boletim_coc/attachments.py`
- Create: `tests/test_attachments.py`

**Interfaces:**
- Consumes: `AppPaths`, open SQLite connection, `boletim_id`, uploaded bytes.
- Produces:
  - `sanitize_filename(name: str) -> str`
  - `save_attachment(conn, paths, boletim_id, original_name, content, mime_type) -> sqlite3.Row`
  - `list_attachments(conn, boletim_id) -> list[sqlite3.Row]`
  - `resolve_attachment_path(paths, row) -> Path`

- [ ] **Step 1: Write failing attachment tests**

`tests/test_attachments.py`:

```python
import pytest

from boletim_coc.attachments import sanitize_filename, save_attachment
from boletim_coc.config import AppPaths
from boletim_coc.db import connect_db, initialize_database
from boletim_coc.models import BoletimDraft
from boletim_coc.repository import create_boletim
from datetime import date, time


def paths(tmp_path):
    for name in ["anexos", "recebidos", "exportados", "logs"]:
        (tmp_path / name).mkdir()
    return AppPaths(
        tmp_path, tmp_path/"boletins.db", tmp_path/"anexos",
        tmp_path/"recebidos", tmp_path/"exportados", tmp_path/"logs",
    )


def draft():
    return BoletimDraft(
        date(2026,9,22), time(8,30), "Hospital", "Centro",
        "Segurança", "Título", "Descrição"
    )


def test_sanitize_filename_removes_path_components():
    assert sanitize_filename(r"..\..\laudo.pdf") == "laudo.pdf"
    assert sanitize_filename("../../foto.jpg") == "foto.jpg"


def test_save_attachment_writes_under_bulletin_directory(tmp_path):
    p = paths(tmp_path)
    conn = connect_db(p); initialize_database(conn)
    row = create_boletim(conn, draft(), "MARIA")
    att = save_attachment(conn, p, row["id"], "foto.jpg", b"abc", "image/jpeg")
    stored = p.root / att["caminho_relativo"]
    assert stored.is_file()
    assert stored.read_bytes() == b"abc"
    assert row["id"] in stored.parts


def test_save_attachment_rejects_disallowed_extension(tmp_path):
    p = paths(tmp_path)
    conn = connect_db(p); initialize_database(conn)
    row = create_boletim(conn, draft(), "MARIA")
    with pytest.raises(ValueError, match="Extensão"):
        save_attachment(conn, p, row["id"], "script.exe", b"MZ", "application/octet-stream")


def test_save_attachment_rejects_oversize(tmp_path, monkeypatch):
    p = paths(tmp_path)
    conn = connect_db(p); initialize_database(conn)
    row = create_boletim(conn, draft(), "MARIA")
    monkeypatch.setattr("boletim_coc.attachments.MAX_ATTACHMENT_BYTES", 2)
    with pytest.raises(ValueError, match="tamanho"):
        save_attachment(conn, p, row["id"], "foto.jpg", b"abc", "image/jpeg")
```

- [ ] **Step 2: Run attachment tests and verify failure**

```bash
pytest tests/test_attachments.py -v
```

Expected: FAIL because `attachments.py` does not exist.

- [ ] **Step 3: Implement secure attachment storage**

`boletim_coc/attachments.py`:

```python
from datetime import datetime, timezone
import hashlib
from pathlib import Path, PurePath
import re
import sqlite3
import uuid

from boletim_coc.config import ALLOWED_EXTENSIONS, MAX_ATTACHMENT_BYTES, AppPaths
from boletim_coc.repository import get_boletim


INVALID_WIN_CHARS = re.compile(r'[<>:"/\\|?*\x00-\x1f]')


def sanitize_filename(name: str) -> str:
    base = PurePath(str(name).replace("\\", "/")).name.strip()
    base = INVALID_WIN_CHARS.sub("_", base).rstrip(". ")
    if not base:
        base = "arquivo"
    return base[:180]


def list_attachments(conn: sqlite3.Connection, boletim_id: str):
    return list(
        conn.execute(
            "select * from anexos where boletim_id=? order by criado_em, nome_original",
            (boletim_id,),
        ).fetchall()
    )


def save_attachment(conn, paths: AppPaths, boletim_id: str, original_name: str, content: bytes, mime_type: str):
    boletim = get_boletim(conn, boletim_id)
    if boletim is None:
        raise KeyError("Boletim não encontrado.")
    if boletim["origem"] == "recebido" or boletim["status"] == "finalizado":
        raise PermissionError("Não é permitido alterar anexos deste boletim.")

    safe = sanitize_filename(original_name)
    suffix = Path(safe).suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS:
        raise ValueError("Extensão de arquivo não permitida.")
    if len(content) > MAX_ATTACHMENT_BYTES:
        raise ValueError("Arquivo excede o tamanho máximo permitido.")

    attachment_id = str(uuid.uuid4())
    stored_name = attachment_id + suffix
    folder = paths.attachments / boletim_id
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / stored_name
    target.write_bytes(content)
    sha = hashlib.sha256(content).hexdigest()
    stamp = datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")
    relative = target.relative_to(paths.root).as_posix()

    conn.execute(
        """
        insert into anexos(
            id,boletim_id,nome_original,nome_armazenado,caminho_relativo,
            mime_type,tamanho_bytes,sha256,criado_em
        ) values(?,?,?,?,?,?,?,?,?)
        """,
        (
            attachment_id, boletim_id, original_name, stored_name, relative,
            mime_type or "application/octet-stream", len(content), sha, stamp,
        ),
    )
    conn.commit()
    return conn.execute("select * from anexos where id=?", (attachment_id,)).fetchone()


def resolve_attachment_path(paths: AppPaths, row) -> Path:
    candidate = (paths.root / row["caminho_relativo"]).resolve()
    root = paths.root.resolve()
    if root != candidate and root not in candidate.parents:
        raise ValueError("Caminho de anexo inválido.")
    return candidate
```

- [ ] **Step 4: Run Task 3 tests**

```bash
pytest tests/test_attachments.py -v
```

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add boletim_coc/attachments.py tests/test_attachments.py
git commit -m "feat: add secure local attachments"
```

---

### Task 4: PDF generation and final content hash

**Files:**
- Create: `boletim_coc/pdf_export.py`
- Create: `tests/test_pdf_export.py`
- Modify: `boletim_coc/repository.py`
- Modify: `tests/test_repository.py`

**Interfaces:**
- Consumes: bulletin row, attachment rows.
- Produces:
  - `canonical_payload(row, attachments) -> dict`
  - `content_hash(row, attachments) -> str`
  - `render_pdf(row, attachments) -> bytes`
  - `finalize_boletim(..., attachments=())` persists `hash_conteudo`.

- [ ] **Step 1: Write failing PDF/hash tests**

`tests/test_pdf_export.py`:

```python
from boletim_coc.pdf_export import canonical_payload, content_hash, render_pdf


def fake_row():
    return {
        "id": "11111111-1111-1111-1111-111111111111",
        "codigo": "COC-2026-000001",
        "origem": "local",
        "windows_user": "MARIA",
        "autor_original": "MARIA",
        "data_ocorrencia": "2026-09-22",
        "hora_ocorrencia": "08:30",
        "local": "Hospital",
        "setor": "Centro cirúrgico",
        "tipo_ocorrencia": "Segurança",
        "titulo": "Queda",
        "descricao": "Descrição",
        "consequencias": "Sem dano",
        "pessoas_envolvidas": "Equipe",
        "acoes_imediatas": "Sinalizado",
        "acoes_preventivas": "Revisão",
        "status": "finalizado",
        "criado_em": "2026-09-22T08:40:00-04:00",
        "atualizado_em": "2026-09-22T08:45:00-04:00",
        "finalizado_em": "2026-09-22T08:45:00-04:00",
        "hash_conteudo": None,
    }


def test_content_hash_is_stable():
    row = fake_row()
    assert content_hash(row, []) == content_hash(dict(row), [])


def test_render_pdf_returns_pdf_bytes():
    data = render_pdf(fake_row(), [])
    assert data.startswith(b"%PDF")
    assert len(data) > 1000


def test_canonical_payload_excludes_machine_specific_fields():
    payload = canonical_payload(fake_row(), [])
    assert "windows_user" not in payload
    assert payload["autor_original"] == "MARIA"
```

- [ ] **Step 2: Run PDF tests and verify failure**

```bash
pytest tests/test_pdf_export.py -v
```

Expected: FAIL because `pdf_export.py` does not exist.

- [ ] **Step 3: Implement canonical payload, hash and PDF**

`boletim_coc/pdf_export.py`:

```python
from io import BytesIO
import hashlib
import json

from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle


def canonical_payload(row, attachments):
    fields = [
        "id","codigo","autor_original","data_ocorrencia","hora_ocorrencia","local",
        "setor","tipo_ocorrencia","titulo","descricao","consequencias",
        "pessoas_envolvidas","acoes_imediatas","acoes_preventivas","status",
        "criado_em","finalizado_em",
    ]
    payload = {field: row[field] for field in fields}
    payload["anexos"] = [
        {
            "nome_original": a["nome_original"],
            "mime_type": a["mime_type"],
            "tamanho_bytes": a["tamanho_bytes"],
            "sha256": a["sha256"],
        }
        for a in attachments
    ]
    return payload


def content_hash(row, attachments) -> str:
    raw = json.dumps(
        canonical_payload(row, attachments),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def render_pdf(row, attachments) -> bytes:
    buf = BytesIO()
    doc = SimpleDocTemplate(
        buf, pagesize=A4,
        rightMargin=18*mm, leftMargin=18*mm,
        topMargin=16*mm, bottomMargin=16*mm,
    )
    styles = getSampleStyleSheet()
    title = ParagraphStyle(
        "CocTitle", parent=styles["Title"], alignment=TA_CENTER,
        fontSize=17, leading=21, spaceAfter=5,
    )
    subtitle = ParagraphStyle(
        "CocSubtitle", parent=styles["Normal"], alignment=TA_CENTER,
        fontSize=9, leading=12, spaceAfter=12,
    )
    body = styles["BodyText"]
    body.leading = 14

    story = [
        Paragraph("COC — Boletim de Ocorrência", title),
        Paragraph(f'{row["codigo"]} · Status: {row["status"].upper()}', subtitle),
    ]

    meta = [
        ["Data", row["data_ocorrencia"], "Hora", row["hora_ocorrencia"]],
        ["Local", row["local"], "Setor", row["setor"]],
        ["Tipo", row["tipo_ocorrencia"], "Autor", row["autor_original"]],
    ]
    table = Table(meta, colWidths=[24*mm, 55*mm, 24*mm, 55*mm])
    table.setStyle(TableStyle([
        ("GRID", (0,0), (-1,-1), 0.35, "#CCCCCC"),
        ("BACKGROUND", (0,0), (0,-1), "#F1F5F9"),
        ("BACKGROUND", (2,0), (2,-1), "#F1F5F9"),
        ("FONTNAME", (0,0), (-1,-1), "Helvetica"),
        ("FONTSIZE", (0,0), (-1,-1), 9),
        ("VALIGN", (0,0), (-1,-1), "TOP"),
        ("PADDING", (0,0), (-1,-1), 5),
    ]))
    story += [table, Spacer(1, 8)]

    sections = [
        ("Título", row["titulo"]),
        ("Descrição da ocorrência", row["descricao"]),
        ("Consequências / impacto", row["consequencias"]),
        ("Pessoas envolvidas", row["pessoas_envolvidas"]),
        ("Ações imediatas", row["acoes_imediatas"]),
        ("Ações preventivas / recomendações", row["acoes_preventivas"]),
    ]
    for label, value in sections:
        story.append(Paragraph(f"<b>{label}</b>", body))
        story.append(Paragraph(str(value or "—").replace("\n", "<br/>"), body))
        story.append(Spacer(1, 6))

    names = ", ".join(a["nome_original"] for a in attachments) or "Nenhum anexo"
    story.append(Paragraph("<b>Anexos</b>", body))
    story.append(Paragraph(names, body))
    story.append(Spacer(1, 8))
    story.append(Paragraph(f'Criado em: {row["criado_em"]}', body))
    if row["finalizado_em"]:
        story.append(Paragraph(f'Finalizado em: {row["finalizado_em"]}', body))

    doc.build(story)
    return buf.getvalue()
```

- [ ] **Step 4: Make finalization persist content hash**

Modify `finalize_boletim` in `boletim_coc/repository.py` to accept `attachments=()` and compute hash before commit:

```python
def finalize_boletim(conn, boletim_id: str, attachments=()):
    from boletim_coc.pdf_export import content_hash
    row = get_boletim(conn, boletim_id)
    _assert_editable(row)
    stamp = now_iso()
    digest = content_hash({**dict(row), "status": "finalizado", "finalizado_em": stamp}, attachments)
    conn.execute(
        """
        update boletins
        set status='finalizado', finalizado_em=?, atualizado_em=?, hash_conteudo=?
        where id=?
        """,
        (stamp, stamp, digest, boletim_id),
    )
    conn.commit()
    return get_boletim(conn, boletim_id)
```

Append repository test:

```python
def test_finalize_persists_content_hash(tmp_path):
    conn = open_db(tmp_path)
    row = create_boletim(conn, sample_draft(), "MARIA")
    final = finalize_boletim(conn, row["id"], attachments=[])
    assert final["hash_conteudo"]
    assert len(final["hash_conteudo"]) == 64
```

- [ ] **Step 5: Run Task 4 tests**

```bash
pytest tests/test_pdf_export.py tests/test_repository.py -v
```

Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add boletim_coc/pdf_export.py boletim_coc/repository.py tests
git commit -m "feat: generate bulletin pdf and integrity hash"
```

---

### Task 5: Export ZIP package with JSON manifest

**Files:**
- Create: `boletim_coc/package_export.py`
- Create: `tests/test_package_export.py`

**Interfaces:**
- Consumes: paths, bulletin row, attachment rows.
- Produces:
  - `build_manifest(row, attachments) -> dict`
  - `export_pdf_file(paths, row, attachments) -> Path`
  - `export_zip(paths, row, attachments) -> Path`

- [ ] **Step 1: Write failing package export tests**

`tests/test_package_export.py`:

```python
import json
import zipfile

from boletim_coc.package_export import export_zip


def test_export_zip_contains_pdf_manifest_and_attachments(tmp_path):
    from boletim_coc.config import AppPaths
    root = tmp_path
    for name in ["anexos","recebidos","exportados","logs"]:
        (root/name).mkdir()
    paths = AppPaths(
        root, root/"boletins.db", root/"anexos",
        root/"recebidos", root/"exportados", root/"logs",
    )
    attachment_file = root/"anexos"/"bulletin"/"x.jpg"
    attachment_file.parent.mkdir(parents=True)
    attachment_file.write_bytes(b"abc")

    row = {
        "id":"bulletin","codigo":"COC-2026-000001","origem":"local",
        "windows_user":"MARIA","autor_original":"MARIA",
        "data_ocorrencia":"2026-09-22","hora_ocorrencia":"08:30",
        "local":"Hospital","setor":"Centro","tipo_ocorrencia":"Segurança",
        "titulo":"Título","descricao":"Descrição","consequencias":"",
        "pessoas_envolvidas":"","acoes_imediatas":"","acoes_preventivas":"",
        "status":"finalizado","criado_em":"2026-09-22T08:40:00-04:00",
        "atualizado_em":"2026-09-22T08:45:00-04:00",
        "finalizado_em":"2026-09-22T08:45:00-04:00",
        "hash_conteudo":"a"*64,
    }
    att = {
        "nome_original":"foto.jpg","mime_type":"image/jpeg","tamanho_bytes":3,
        "sha256":"ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
        "caminho_relativo":"anexos/bulletin/x.jpg",
    }
    target = export_zip(paths, row, [att])
    with zipfile.ZipFile(target) as zf:
        names = set(zf.namelist())
        assert {"boletim.pdf","boletim.json","anexos/foto.jpg"} <= names
        manifest = json.loads(zf.read("boletim.json"))
        assert manifest["format_version"] == 1
        assert manifest["boletim"]["id"] == "bulletin"
        assert manifest["boletim"]["hash_conteudo"] == "a"*64
```

- [ ] **Step 2: Run export test and verify failure**

```bash
pytest tests/test_package_export.py -v
```

Expected: FAIL because `package_export.py` does not exist.

- [ ] **Step 3: Implement manifest/PDF/ZIP export**

`boletim_coc/package_export.py`:

```python
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import zipfile

from boletim_coc.attachments import resolve_attachment_path
from boletim_coc.pdf_export import canonical_payload, render_pdf


def build_manifest(row, attachments):
    return {
        "format_version": 1,
        "exported_at": datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds"),
        "boletim": {
            **canonical_payload(row, attachments),
            "hash_conteudo": row["hash_conteudo"],
        },
    }


def export_pdf_file(paths, row, attachments) -> Path:
    if row["status"] != "finalizado":
        raise ValueError("Finalize o boletim antes de exportar.")
    target = paths.exports / f'{row["codigo"]}.pdf'
    target.write_bytes(render_pdf(row, attachments))
    return target


def export_zip(paths, row, attachments) -> Path:
    if row["status"] != "finalizado":
        raise ValueError("Finalize o boletim antes de exportar.")
    manifest = build_manifest(row, attachments)
    target = paths.exports / f'{row["codigo"]}.zip'
    temp = target.with_suffix(".zip.part")
    try:
        with zipfile.ZipFile(temp, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("boletim.pdf", render_pdf(row, attachments))
            zf.writestr(
                "boletim.json",
                json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8"),
            )
            for att in attachments:
                source = resolve_attachment_path(paths, att)
                raw = source.read_bytes()
                if hashlib.sha256(raw).hexdigest() != att["sha256"]:
                    raise ValueError(f'Integridade inválida no anexo {att["nome_original"]}.')
                zf.writestr(f'anexos/{Path(att["nome_original"]).name}', raw)
        temp.replace(target)
    except Exception:
        temp.unlink(missing_ok=True)
        raise
    return target
```

- [ ] **Step 4: Add partial-export cleanup test**

Append:

```python
def test_export_zip_does_not_leave_partial_file_on_hash_failure(tmp_path):
    # Reuse the same fixture shape but provide a wrong attachment hash.
    # Expected behavior: ValueError and no .zip.part file left behind.
    import pytest
    from boletim_coc.config import AppPaths

    for name in ["anexos","recebidos","exportados","logs"]:
        (tmp_path/name).mkdir()
    paths = AppPaths(
        tmp_path, tmp_path/"boletins.db", tmp_path/"anexos",
        tmp_path/"recebidos", tmp_path/"exportados", tmp_path/"logs",
    )
    p = tmp_path/"anexos"/"bulletin"/"x.jpg"
    p.parent.mkdir(parents=True); p.write_bytes(b"abc")
    row = {
        "id":"bulletin","codigo":"COC-2026-000002","origem":"local",
        "windows_user":"MARIA","autor_original":"MARIA","data_ocorrencia":"2026-09-22",
        "hora_ocorrencia":"08:30","local":"Hospital","setor":"Centro",
        "tipo_ocorrencia":"Segurança","titulo":"Título","descricao":"Descrição",
        "consequencias":"","pessoas_envolvidas":"","acoes_imediatas":"",
        "acoes_preventivas":"","status":"finalizado",
        "criado_em":"2026-09-22T08:40:00-04:00",
        "atualizado_em":"2026-09-22T08:45:00-04:00",
        "finalizado_em":"2026-09-22T08:45:00-04:00",
        "hash_conteudo":"a"*64,
    }
    att = {
        "nome_original":"foto.jpg","mime_type":"image/jpeg","tamanho_bytes":3,
        "sha256":"0"*64,"caminho_relativo":"anexos/bulletin/x.jpg",
    }
    with pytest.raises(ValueError, match="Integridade"):
        export_zip(paths, row, [att])
    assert not any(paths.exports.glob("*.part"))
```

- [ ] **Step 5: Run Task 5 tests**

```bash
pytest tests/test_package_export.py -v
```

Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add boletim_coc/package_export.py tests/test_package_export.py
git commit -m "feat: export portable bulletin packages"
```

---

### Task 6: Safe ZIP import and read-only received records

**Files:**
- Create: `boletim_coc/package_import.py`
- Create: `tests/test_package_import.py`
- Modify: `boletim_coc/repository.py`

**Interfaces:**
- Consumes: `zip_path`, `AppPaths`, open SQLite connection, current Windows user.
- Produces:
  - `validate_member_name(name: str) -> None`
  - `import_package(conn, paths, zip_path, windows_user) -> sqlite3.Row`
  - `list_received(conn, windows_user) -> list[sqlite3.Row]`

- [ ] **Step 1: Add received-list query**

Add to `boletim_coc/repository.py`:

```python
def list_received(conn, windows_user: str):
    return list(
        conn.execute(
            """
            select * from boletins
            where origem='recebido' and windows_user=?
            order by criado_em desc
            """,
            (windows_user,),
        ).fetchall()
    )
```

- [ ] **Step 2: Write failing import tests**

`tests/test_package_import.py`:

```python
import json
from pathlib import Path
import zipfile

import pytest

from boletim_coc.config import AppPaths
from boletim_coc.db import connect_db, initialize_database
from boletim_coc.package_import import import_package, validate_member_name


def paths(tmp_path):
    for name in ["anexos","recebidos","exportados","logs"]:
        (tmp_path/name).mkdir()
    return AppPaths(
        tmp_path, tmp_path/"boletins.db", tmp_path/"anexos",
        tmp_path/"recebidos", tmp_path/"exportados", tmp_path/"logs",
    )


def manifest():
    return {
        "format_version": 1,
        "exported_at": "2026-09-22T09:00:00-04:00",
        "boletim": {
            "id":"11111111-1111-1111-1111-111111111111",
            "codigo":"COC-2026-000001",
            "autor_original":"MARIA",
            "data_ocorrencia":"2026-09-22",
            "hora_ocorrencia":"08:30",
            "local":"Hospital",
            "setor":"Centro",
            "tipo_ocorrencia":"Segurança",
            "titulo":"Título",
            "descricao":"Descrição",
            "consequencias":"",
            "pessoas_envolvidas":"",
            "acoes_imediatas":"",
            "acoes_preventivas":"",
            "status":"finalizado",
            "criado_em":"2026-09-22T08:40:00-04:00",
            "finalizado_em":"2026-09-22T08:45:00-04:00",
            "anexos":[],
            "hash_conteudo":"a"*64,
        },
    }


def make_zip(path, data=None):
    with zipfile.ZipFile(path, "w") as zf:
        zf.writestr("boletim.json", json.dumps(data or manifest()))
        zf.writestr("boletim.pdf", b"%PDF-1.4 fake")
    return path


def test_validate_member_name_rejects_path_traversal():
    for bad in ["../evil.txt", "/absolute.txt", "C:/evil.txt", "anexos/../../evil.txt"]:
        with pytest.raises(ValueError, match="Caminho"):
            validate_member_name(bad)


def test_import_package_creates_received_readonly_record(tmp_path):
    p = paths(tmp_path)
    conn = connect_db(p); initialize_database(conn)
    row = import_package(conn, p, make_zip(tmp_path/"one.zip"), "JOAO")
    assert row["origem"] == "recebido"
    assert row["windows_user"] == "JOAO"
    assert row["autor_original"] == "MARIA"
    assert row["status"] == "finalizado"


def test_import_package_rejects_duplicate_bulletin(tmp_path):
    p = paths(tmp_path)
    conn = connect_db(p); initialize_database(conn)
    source = make_zip(tmp_path/"one.zip")
    import_package(conn, p, source, "JOAO")
    with pytest.raises(ValueError, match="já foi importado"):
        import_package(conn, p, source, "JOAO")


def test_import_package_rejects_wrong_format_version(tmp_path):
    p = paths(tmp_path)
    conn = connect_db(p); initialize_database(conn)
    data = manifest(); data["format_version"] = 99
    with pytest.raises(ValueError, match="versão"):
        import_package(conn, p, make_zip(tmp_path/"bad.zip", data), "JOAO")
```

- [ ] **Step 3: Run import tests and verify failure**

```bash
pytest tests/test_package_import.py -v
```

Expected: FAIL because `package_import.py` does not exist.

- [ ] **Step 4: Implement safe ZIP import with transaction**

`boletim_coc/package_import.py`:

```python
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import sqlite3
import uuid
import zipfile

from boletim_coc.config import ALLOWED_EXTENSIONS, AppPaths
from boletim_coc.pdf_export import content_hash
from boletim_coc.repository import get_boletim


def validate_member_name(name: str) -> None:
    p = PurePosixPath(name)
    if p.is_absolute() or ".." in p.parts:
        raise ValueError("Caminho inválido dentro do ZIP.")
    if len(p.parts) and ":" in p.parts[0]:
        raise ValueError("Caminho absoluto do Windows não é permitido.")


def _package_sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def import_package(conn: sqlite3.Connection, paths: AppPaths, zip_path: Path, windows_user: str):
    zip_path = Path(zip_path)
    package_hash = _package_sha(zip_path)

    if conn.execute("select 1 from importacoes where hash_pacote=?", (package_hash,)).fetchone():
        raise ValueError("Este pacote já foi importado.")

    temp_root = paths.received / (".import-" + str(uuid.uuid4()))
    temp_root.mkdir(parents=True)
    try:
        with zipfile.ZipFile(zip_path) as zf:
            for info in zf.infolist():
                validate_member_name(info.filename)
            names = set(zf.namelist())
            if "boletim.json" not in names or "boletim.pdf" not in names:
                raise ValueError("Pacote inválido: faltam boletim.json ou boletim.pdf.")

            manifest = json.loads(zf.read("boletim.json"))
            if manifest.get("format_version") != 1:
                raise ValueError("Versão de pacote não suportada.")
            b = manifest.get("boletim") or {}
            bulletin_id = str(b.get("id") or "")
            if not bulletin_id or not b.get("codigo"):
                raise ValueError("Manifesto do boletim está incompleto.")
            if get_boletim(conn, bulletin_id):
                raise ValueError("Este boletim já foi importado.")

            target_dir = paths.received / bulletin_id
            if target_dir.exists():
                raise ValueError("Diretório do boletim recebido já existe.")

            attachment_rows = []
            for item in b.get("anexos", []):
                name = Path(str(item["nome_original"])).name
                ext = Path(name).suffix.lower()
                if ext not in ALLOWED_EXTENSIONS:
                    raise ValueError(f"Extensão de anexo não permitida: {ext}")
                member = f"anexos/{name}"
                if member not in names:
                    raise ValueError(f"Anexo ausente no pacote: {name}")
                raw = zf.read(member)
                actual = hashlib.sha256(raw).hexdigest()
                if actual != item["sha256"]:
                    raise ValueError(f"Hash inválido para o anexo: {name}")
                stored = str(uuid.uuid4()) + ext
                (temp_root / stored).write_bytes(raw)
                attachment_rows.append((item, stored, raw))

            actual_content_hash = content_hash(
                {
                    **b,
                    "windows_user": windows_user,
                    "origem": "recebido",
                    "atualizado_em": b.get("finalizado_em") or b.get("criado_em"),
                    "hash_conteudo": b.get("hash_conteudo"),
                },
                [
                    {
                        "nome_original": item["nome_original"],
                        "mime_type": item["mime_type"],
                        "tamanho_bytes": item["tamanho_bytes"],
                        "sha256": item["sha256"],
                    }
                    for item, _, _ in attachment_rows
                ],
            )
            if actual_content_hash != b.get("hash_conteudo"):
                raise ValueError("Integridade do boletim inválida.")

            target_dir.mkdir(parents=True)
            for item, stored, raw in attachment_rows:
                shutil.move(str(temp_root / stored), target_dir / stored)

            stamp = datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")
            with conn:
                conn.execute(
                    """
                    insert into boletins(
                        id,codigo,origem,windows_user,autor_original,
                        data_ocorrencia,hora_ocorrencia,local,setor,tipo_ocorrencia,
                        titulo,descricao,consequencias,pessoas_envolvidas,
                        acoes_imediatas,acoes_preventivas,status,criado_em,atualizado_em,
                        finalizado_em,hash_conteudo
                    ) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    """,
                    (
                        bulletin_id,b["codigo"],"recebido",windows_user,b["autor_original"],
                        b["data_ocorrencia"],b["hora_ocorrencia"],b["local"],b["setor"],
                        b["tipo_ocorrencia"],b["titulo"],b["descricao"],
                        b.get("consequencias",""),b.get("pessoas_envolvidas",""),
                        b.get("acoes_imediatas",""),b.get("acoes_preventivas",""),
                        "finalizado",b["criado_em"],stamp,b.get("finalizado_em"),
                        b["hash_conteudo"],
                    ),
                )
                for item, stored, raw in attachment_rows:
                    att_id = str(uuid.uuid4())
                    relative = (target_dir / stored).relative_to(paths.root).as_posix()
                    conn.execute(
                        """
                        insert into anexos(
                            id,boletim_id,nome_original,nome_armazenado,caminho_relativo,
                            mime_type,tamanho_bytes,sha256,criado_em
                        ) values(?,?,?,?,?,?,?,?,?)
                        """,
                        (
                            att_id, bulletin_id, item["nome_original"], stored, relative,
                            item["mime_type"], item["tamanho_bytes"], item["sha256"], stamp,
                        ),
                    )
                conn.execute(
                    """
                    insert into importacoes(id,boletim_id,arquivo_origem,importado_em,hash_pacote)
                    values(?,?,?,?,?)
                    """,
                    (str(uuid.uuid4()), bulletin_id, zip_path.name, stamp, package_hash),
                )
            return get_boletim(conn, bulletin_id)
    except Exception:
        shutil.rmtree(temp_root, ignore_errors=True)
        # If the DB transaction failed after files were moved, remove only the new target
        # when the bulletin was not committed.
        try:
            b
        except UnboundLocalError:
            b = {}
        bulletin_id = str(b.get("id") or "")
        if bulletin_id and not get_boletim(conn, bulletin_id):
            shutil.rmtree(paths.received / bulletin_id, ignore_errors=True)
        raise
    finally:
        shutil.rmtree(temp_root, ignore_errors=True)
```

- [ ] **Step 5: Add a regression test for renamed duplicate ZIP**

Append:

```python
def test_import_same_bytes_under_new_filename_is_duplicate(tmp_path):
    p = paths(tmp_path)
    conn = connect_db(p); initialize_database(conn)
    first = make_zip(tmp_path/"first.zip")
    second = tmp_path/"renamed.zip"
    second.write_bytes(first.read_bytes())
    import_package(conn, p, first, "JOAO")
    with pytest.raises(ValueError, match="já foi importado"):
        import_package(conn, p, second, "JOAO")
```

- [ ] **Step 6: Run Task 6 tests**

```bash
pytest tests/test_package_import.py tests/test_repository.py -v
```

Expected: PASS.

- [ ] **Step 7: Commit**

```bash
git add boletim_coc/package_import.py boletim_coc/repository.py tests/test_package_import.py
git commit -m "feat: import received bulletins safely"
```

---

### Task 7: Streamlit UI — Novo Registro, Meus Registros, Recebidos e detalhe

**Files:**
- Create: `app.py`
- Create: `boletim_coc/theme.py`
- Create: `boletim_coc/views/__init__.py`
- Create: `boletim_coc/views/new_record.py`
- Create: `boletim_coc/views/my_records.py`
- Create: `boletim_coc/views/received.py`
- Create: `boletim_coc/views/detail.py`

**Interfaces:**
- Consumes: all services from Tasks 1–6.
- Produces: local Streamlit application with navigation state `coc_section` and optional `selected_boletim_id`.

- [ ] **Step 1: Create shared visual theme**

`boletim_coc/theme.py`:

```python
CSS = """
<style>
.stApp{background:#f5f8fb}
.block-container{max-width:1320px;padding-top:1.5rem;padding-bottom:3rem}
[data-testid="stSidebar"]{background:#eef4fb;border-right:1px solid #d8e3ef}
.coc-head{background:linear-gradient(120deg,#0b5ea8,#1879c6);padding:24px 28px;
border-radius:18px;color:#fff;margin-bottom:18px;box-shadow:0 10px 26px rgba(11,94,168,.16)}
.coc-head h1{margin:0;font-size:1.85rem}
.coc-head p{margin:.35rem 0 0;color:#e8f3ff}
.coc-card{background:#fff;border:1px solid #dce6f0;border-radius:16px;
padding:18px 20px;margin-bottom:12px;box-shadow:0 4px 14px rgba(35,71,103,.05)}
.coc-code{font-weight:800;color:#0b5ea8}
.coc-muted{color:#718096;font-size:.86rem}
[data-testid="stForm"]{background:#fff;border:1px solid #dce6f0;border-radius:16px;padding:16px}
.stButton>button{border-radius:10px}
</style>
"""


def apply_theme(st):
    st.markdown(CSS, unsafe_allow_html=True)


def header(st, title: str, subtitle: str):
    st.markdown(
        f'<div class="coc-head"><h1>{title}</h1><p>{subtitle}</p></div>',
        unsafe_allow_html=True,
    )
```

- [ ] **Step 2: Implement Novo Registro view**

`boletim_coc/views/new_record.py`:

```python
from datetime import datetime

from boletim_coc.attachments import save_attachment
from boletim_coc.models import BoletimDraft
from boletim_coc.repository import create_boletim, finalize_boletim
from boletim_coc.theme import header


TIPOS = [
    "Assistencial", "Segurança", "Administrativa",
    "Equipamento", "Documentação", "Outro",
]


def render(st, conn, paths, windows_user):
    header(st, "Boletim de Ocorrência", "Novo registro · segurança e melhoria contínua")
    with st.form("novo_boletim", clear_on_submit=False):
        c1, c2 = st.columns(2)
        data = c1.date_input("Data da ocorrência", value=datetime.now().date())
        hora = c2.time_input("Hora da ocorrência", value=datetime.now().time().replace(second=0, microsecond=0))
        c3, c4 = st.columns(2)
        local = c3.text_input("Local *")
        setor = c4.text_input("Setor *")
        tipo = st.selectbox("Tipo da ocorrência *", TIPOS)
        titulo = st.text_input("Título curto *")
        descricao = st.text_area("Descrição detalhada *", height=150)
        consequencias = st.text_area("Consequências / impacto", height=90)
        pessoas = st.text_area("Pessoas envolvidas", height=90)
        imediatas = st.text_area("Ações imediatas tomadas", height=90)
        preventivas = st.text_area("Ações preventivas / recomendações", height=90)
        uploads = st.file_uploader(
            "Anexos",
            type=["pdf","jpg","jpeg","png","docx","xlsx"],
            accept_multiple_files=True,
        )
        c5, c6 = st.columns(2)
        save = c5.form_submit_button("Salvar rascunho", use_container_width=True)
        finish = c6.form_submit_button("Salvar e finalizar", type="primary", use_container_width=True)

    if save or finish:
        try:
            draft = BoletimDraft(
                data, hora, local, setor, tipo, titulo, descricao,
                consequencias, pessoas, imediatas, preventivas,
            )
            row = create_boletim(conn, draft, windows_user)
            attachment_rows = []
            for upload in uploads or []:
                attachment_rows.append(
                    save_attachment(
                        conn, paths, row["id"], upload.name,
                        upload.getvalue(), upload.type or "application/octet-stream",
                    )
                )
            if finish:
                row = finalize_boletim(conn, row["id"], attachment_rows)
            st.success(f'{row["codigo"]} salvo com sucesso.')
            st.session_state.selected_boletim_id = row["id"]
            st.session_state.coc_section = "detail"
            st.rerun()
        except Exception as exc:
            st.error(str(exc))
```

- [ ] **Step 3: Implement My Records view**

`boletim_coc/views/my_records.py`:

```python
from boletim_coc.repository import list_my_records
from boletim_coc.theme import header


def render(st, conn, windows_user):
    header(st, "Meus Registros", f"Registros locais de {windows_user}")
    c1, c2, c3 = st.columns([2,1,1])
    query = c1.text_input("Pesquisar", placeholder="Código, título, descrição ou local")
    status = c2.selectbox("Status", ["Todos","rascunho","finalizado"])
    tipo = c3.text_input("Tipo", placeholder="Todos")
    rows = list_my_records(
        conn, windows_user, query=query,
        status=None if status == "Todos" else status,
        tipo=tipo.strip() or None,
    )
    if not rows:
        st.info("Nenhum registro encontrado.")
        return
    for row in rows:
        with st.container(border=True):
            a, b = st.columns([5,1])
            a.markdown(f'**{row["codigo"]} — {row["titulo"]}**')
            a.caption(
                f'{row["data_ocorrencia"]} · {row["local"]} · '
                f'{row["tipo_ocorrencia"]} · {row["status"]}'
            )
            if b.button("Abrir", key=f'open-{row["id"]}', use_container_width=True):
                st.session_state.selected_boletim_id = row["id"]
                st.session_state.coc_section = "detail"
                st.rerun()
```

- [ ] **Step 4: Implement Received view**

`boletim_coc/views/received.py`:

```python
from pathlib import Path
import tempfile

from boletim_coc.package_import import import_package
from boletim_coc.repository import list_received
from boletim_coc.theme import header


def render(st, conn, paths, windows_user):
    header(st, "Recebidos", "Importe boletins enviados por outro computador")
    upload = st.file_uploader("Importar boletim (.zip)", type=["zip"])
    if upload and st.button("Importar", type="primary"):
        temp_path = None
        try:
            with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tmp:
                tmp.write(upload.getvalue())
                temp_path = Path(tmp.name)
            row = import_package(conn, paths, temp_path, windows_user)
            st.success(f'{row["codigo"]} importado com sucesso.')
            st.session_state.selected_boletim_id = row["id"]
            st.session_state.coc_section = "detail"
            st.rerun()
        except Exception as exc:
            st.error(str(exc))
        finally:
            if temp_path:
                temp_path.unlink(missing_ok=True)

    rows = list_received(conn, windows_user)
    st.subheader("Boletins recebidos")
    if not rows:
        st.info("Nenhum boletim recebido.")
    for row in rows:
        with st.container(border=True):
            a, b = st.columns([5,1])
            a.markdown(f'**{row["codigo"]} — {row["titulo"]}**')
            a.caption(f'Autor: {row["autor_original"]} · {row["data_ocorrencia"]}')
            if b.button("Abrir", key=f'received-{row["id"]}', use_container_width=True):
                st.session_state.selected_boletim_id = row["id"]
                st.session_state.coc_section = "detail"
                st.rerun()
```

- [ ] **Step 5: Implement Detail view with PDF/ZIP download**

`boletim_coc/views/detail.py`:

```python
from boletim_coc.attachments import list_attachments, resolve_attachment_path
from boletim_coc.package_export import export_pdf_file, export_zip
from boletim_coc.repository import finalize_boletim, get_boletim
from boletim_coc.theme import header


def render(st, conn, paths):
    bulletin_id = st.session_state.get("selected_boletim_id")
    row = get_boletim(conn, bulletin_id) if bulletin_id else None
    if row is None:
        st.warning("Boletim não encontrado.")
        return

    header(st, row["codigo"], row["titulo"])
    attachments = list_attachments(conn, row["id"])
    read_only = row["origem"] == "recebido" or row["status"] == "finalizado"

    st.caption(
        f'Autor: {row["autor_original"]} · Origem: {row["origem"]} · '
        f'Status: {row["status"]}'
    )
    c1, c2, c3 = st.columns(3)
    c1.metric("Data", row["data_ocorrencia"])
    c2.metric("Hora", row["hora_ocorrencia"])
    c3.metric("Tipo", row["tipo_ocorrencia"])

    sections = [
        ("Local / Setor", f'{row["local"]} · {row["setor"]}'),
        ("Descrição", row["descricao"]),
        ("Consequências / impacto", row["consequencias"]),
        ("Pessoas envolvidas", row["pessoas_envolvidas"]),
        ("Ações imediatas", row["acoes_imediatas"]),
        ("Ações preventivas", row["acoes_preventivas"]),
    ]
    for title, value in sections:
        st.markdown(f"#### {title}")
        st.write(value or "—")

    st.markdown("#### Anexos")
    if not attachments:
        st.caption("Nenhum anexo.")
    for att in attachments:
        file_path = resolve_attachment_path(paths, att)
        st.download_button(
            f'Baixar {att["nome_original"]}',
            data=file_path.read_bytes(),
            file_name=att["nome_original"],
            mime=att["mime_type"],
            key=f'att-{att["id"]}',
        )

    if row["origem"] == "local" and row["status"] == "rascunho":
        if st.button("Finalizar boletim", type="primary"):
            finalize_boletim(conn, row["id"], attachments)
            st.rerun()

    row = get_boletim(conn, row["id"])
    if row["status"] == "finalizado":
        pdf = export_pdf_file(paths, row, attachments)
        package = export_zip(paths, row, attachments)
        d1, d2 = st.columns(2)
        d1.download_button(
            "Baixar PDF", pdf.read_bytes(), file_name=pdf.name,
            mime="application/pdf", use_container_width=True,
        )
        d2.download_button(
            "Baixar ZIP completo", package.read_bytes(), file_name=package.name,
            mime="application/zip", use_container_width=True,
        )

    if read_only:
        st.info("Este boletim está em modo somente leitura.")
```

- [ ] **Step 6: Implement Streamlit shell and navigation**

`app.py`:

```python
import streamlit as st

from boletim_coc.config import resolve_paths
from boletim_coc.db import connect_db, initialize_database
from boletim_coc.identity import current_windows_user
from boletim_coc.theme import apply_theme

st.set_page_config(
    page_title="COC · Boletim de Ocorrência",
    page_icon="📝",
    layout="wide",
)

paths = resolve_paths()
conn = connect_db(paths)
initialize_database(conn)
windows_user = current_windows_user()
apply_theme(st)

if "coc_section" not in st.session_state:
    st.session_state.coc_section = "new"

with st.sidebar:
    st.markdown("## COC")
    st.caption("Boletim de Ocorrência")
    st.info(f"Windows: {windows_user}")
    section = st.session_state.coc_section
    if st.button("📝 Novo Registro", use_container_width=True, type="primary" if section == "new" else "secondary"):
        st.session_state.coc_section = "new"; st.rerun()
    if st.button("📚 Meus Registros", use_container_width=True, type="primary" if section == "mine" else "secondary"):
        st.session_state.coc_section = "mine"; st.rerun()
    if st.button("📥 Recebidos", use_container_width=True, type="primary" if section == "received" else "secondary"):
        st.session_state.coc_section = "received"; st.rerun()

section = st.session_state.coc_section
if section == "new":
    from boletim_coc.views.new_record import render
    render(st, conn, paths, windows_user)
elif section == "mine":
    from boletim_coc.views.my_records import render
    render(st, conn, windows_user)
elif section == "received":
    from boletim_coc.views.received import render
    render(st, conn, paths, windows_user)
else:
    from boletim_coc.views.detail import render
    render(st, conn, paths)
```

- [ ] **Step 7: Run the application manually**

Run:

```bash
streamlit run app.py
```

Expected:
- sidebar shows the current Windows account;
- no login screen appears;
- all three sections render;
- a new record can be saved;
- **Meus Registros** shows only the current Windows user;
- a finalized bulletin shows PDF and ZIP download buttons;
- `.zip` can be imported into **Recebidos**;
- received bulletins display “somente leitura”.

- [ ] **Step 8: Run all automated tests**

```bash
pytest -q
```

Expected: all tests PASS.

- [ ] **Step 9: Commit**

```bash
git add app.py boletim_coc
git commit -m "feat: add Streamlit bulletin workflow"
```

---

### Task 8: Windows launcher, public README and first-run verification

**Files:**
- Create: `run_coc.bat`
- Create: `README.md`
- Modify: `.gitignore`

**Interfaces:**
- Consumes: installed Python/requirements.
- Produces: one-click local launch and public installation instructions.

- [ ] **Step 1: Create Windows launcher**

`run_coc.bat`:

```bat
@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    py -3.12 -m venv .venv
    if errorlevel 1 (
        echo Nao foi possivel criar o ambiente Python.
        pause
        exit /b 1
    )
    call ".venv\Scripts\activate.bat"
    python -m pip install --upgrade pip
    pip install -r requirements.txt
) else (
    call ".venv\Scripts\activate.bat"
)

python -m streamlit run app.py --server.headless true
endlocal
```

- [ ] **Step 2: Write public README**

`README.md`:

```markdown
# COC · Boletim de Ocorrência

Aplicativo local em Streamlit para registrar, guardar e compartilhar boletins de ocorrência.

## Características

- roda no Windows;
- não exige usuário ou senha do aplicativo;
- identifica automaticamente o usuário do Windows;
- salva dados em SQLite no próprio computador;
- salva anexos localmente;
- gera PDF;
- gera ZIP com PDF + JSON + anexos;
- importa boletins recebidos em modo somente leitura;
- não depende de Supabase ou internet depois da instalação.

## Instalação rápida

1. Instale Python 3.12 ou superior.
2. Baixe ou clone este repositório.
3. Execute `run_coc.bat`.
4. Na primeira execução, as dependências serão instaladas.
5. O navegador abrirá o aplicativo local.

## Onde os dados ficam

Por padrão:

`%LOCALAPPDATA%\COC\BoletimOcorrencia`

O repositório não contém dados reais da COC.

## Compartilhamento

Finalize um boletim e use:

- **Baixar PDF** para impressão, WhatsApp ou e-mail;
- **Baixar ZIP completo** para enviar a outro usuário deste aplicativo.

O destinatário abre **Recebidos**, importa o ZIP e recebe uma cópia somente leitura.

## Privacidade

Nenhum boletim é enviado automaticamente para a internet. A publicação deste código no GitHub não publica bancos, anexos nem registros locais.
```

- [ ] **Step 3: Verify first-run behavior in a clean temporary LOCALAPPDATA**

PowerShell:

```powershell
$env:LOCALAPPDATA = "$env:TEMP\COC-Boletim-Teste"
python -m streamlit run app.py --server.headless true
```

Expected: `%TEMP%\COC-Boletim-Teste\COC\BoletimOcorrencia` is created automatically and contains `boletins.db`, `anexos`, `recebidos`, `exportados`, and `logs`.

- [ ] **Step 4: Run the full regression suite**

```bash
pytest -q
```

Expected: all tests PASS.

- [ ] **Step 5: Confirm public repository hygiene**

Run:

```bash
git status --short
git ls-files | findstr /R /I "\.db$ \.sqlite$ \.sqlite3$"
```

Expected:
- `git status` contains only intended source/docs changes;
- second command returns no database files.

- [ ] **Step 6: Commit**

```bash
git add run_coc.bat README.md .gitignore
git commit -m "docs: add Windows launcher and public setup"
```

---

### Task 9: End-to-end acceptance test with two Windows identities simulated

**Files:**
- Create: `tests/test_end_to_end_exchange.py`

**Interfaces:**
- Consumes: full service layer from Tasks 1–6.
- Produces: regression proof for create → attach → finalize → export → import → read-only flow.

- [ ] **Step 1: Write end-to-end test**

`tests/test_end_to_end_exchange.py`:

```python
from datetime import date, time
import shutil

import pytest

from boletim_coc.attachments import list_attachments, save_attachment
from boletim_coc.config import AppPaths
from boletim_coc.db import connect_db, initialize_database
from boletim_coc.models import BoletimDraft
from boletim_coc.package_export import export_zip
from boletim_coc.package_import import import_package
from boletim_coc.repository import (
    create_boletim, finalize_boletim, list_my_records,
    list_received, update_draft,
)


def paths(root):
    for name in ["anexos","recebidos","exportados","logs"]:
        (root/name).mkdir(parents=True, exist_ok=True)
    return AppPaths(
        root, root/"boletins.db", root/"anexos",
        root/"recebidos", root/"exportados", root/"logs",
    )


def test_exchange_between_two_local_profiles(tmp_path):
    maria_paths = paths(tmp_path/"maria")
    joao_paths = paths(tmp_path/"joao")
    maria = connect_db(maria_paths); initialize_database(maria)
    joao = connect_db(joao_paths); initialize_database(joao)

    row = create_boletim(
        maria,
        BoletimDraft(
            date(2026,9,22), time(9,15), "Hospital COC", "Centro cirúrgico",
            "Segurança", "Teste de troca", "Ocorrência de teste.",
        ),
        "MARIA",
    )
    save_attachment(
        maria, maria_paths, row["id"], "evidencia.jpg", b"imagem",
        "image/jpeg",
    )
    attachments = list_attachments(maria, row["id"])
    final = finalize_boletim(maria, row["id"], attachments)
    package = export_zip(maria_paths, final, attachments)

    received = import_package(joao, joao_paths, package, "JOAO")

    assert len(list_my_records(maria, "MARIA")) == 1
    assert len(list_my_records(joao, "JOAO")) == 0
    assert len(list_received(joao, "JOAO")) == 1
    assert received["autor_original"] == "MARIA"

    with pytest.raises(PermissionError):
        update_draft(joao, received["id"], {"titulo": "Não pode"})
```

- [ ] **Step 2: Run end-to-end test**

```bash
pytest tests/test_end_to_end_exchange.py -v
```

Expected: PASS.

- [ ] **Step 3: Run complete suite and inspect warnings**

```bash
pytest -q
```

Expected: all tests PASS and no warnings indicating unclosed SQLite databases or deprecated ReportLab/Streamlit APIs used by the service layer.

- [ ] **Step 4: Commit acceptance test**

```bash
git add tests/test_end_to_end_exchange.py
git commit -m "test: cover local bulletin exchange end to end"
```

---

## Final Verification Before Release

Run:

```bash
pytest -q
python -m compileall app.py boletim_coc
```

Expected:
- all tests PASS;
- compilation completes without syntax errors.

Manual Windows checklist:

```text
[ ] run_coc.bat starts the app without asking for login/password
[ ] current Windows username appears in sidebar
[ ] new draft saves locally
[ ] draft can be finalized
[ ] finalized bulletin cannot be edited
[ ] PDF downloads and opens
[ ] ZIP contains boletim.pdf, boletim.json and attachments
[ ] another local profile can import the ZIP
[ ] imported record appears only in Recebidos
[ ] received record is read-only
[ ] importing the same package twice is rejected
[ ] no .db, attachment or export is tracked by Git
```

Release readiness condition: only publish/tag the first public version after both automated tests and the manual Windows checklist pass.
